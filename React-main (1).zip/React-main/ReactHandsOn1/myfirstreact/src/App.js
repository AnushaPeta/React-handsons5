import React ,{Component} from 'react';
class App extends Component
{
  render()
  {
    return(
      <center>
        <h1>Welcome the first session of react</h1>
      </center>
    )
  }
}
export default App